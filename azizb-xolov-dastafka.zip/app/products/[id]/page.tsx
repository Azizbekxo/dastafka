"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowLeft, Minus, Plus, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Mock product data
const products = [
  {
    id: 1,
    name: "Non mahsulotlari",
    price: 5000,
    description: "Yangi pishirilgan non mahsulotlari. Tarkibida: un, suv, tuz, xamirturush.",
    category: "Oziq-ovqat",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: 2,
    name: "Sut mahsulotlari",
    price: 15000,
    description: "Yangi sut mahsulotlari. Tarkibida: sut, qaymoq, kefir.",
    category: "Oziq-ovqat",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: 3,
    name: "Go'sht mahsulotlari",
    price: 45000,
    description: "Yangi go'sht mahsulotlari. Tarkibida: mol go'shti, qo'y go'shti.",
    category: "Oziq-ovqat",
    image: "/placeholder.svg?height=400&width=400",
  },
]

export default function ProductPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const productId = Number.parseInt(params.id)
  const product = products.find((p) => p.id === productId) || products[0]

  const [quantity, setQuantity] = useState(1)

  const increaseQuantity = () => {
    setQuantity(quantity + 1)
  }

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  const addToCart = () => {
    // In a real app, you would add the product to the cart state or localStorage
    // For this demo, we'll just navigate to the cart page
    router.push("/cart")
  }

  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      <div className="mb-8">
        <Link href="/products" className="flex items-center text-gray-600 hover:text-blue-600">
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span>Barcha mahsulotlarga qaytish</span>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-gray-50 rounded-lg overflow-hidden">
          <img src={product.image || "/placeholder.svg"} alt={product.name} className="w-full h-full object-contain" />
        </div>

        <div>
          <h1 className="text-2xl font-bold mb-2">{product.name}</h1>
          <p className="text-gray-500 mb-4">{product.category}</p>
          <p className="text-3xl font-bold text-blue-600 mb-6">{product.price.toLocaleString()} so'm</p>

          <div className="mb-6">
            <p className="text-gray-700">{product.description}</p>
          </div>

          <div className="flex items-center space-x-4 mb-6">
            <span className="text-gray-700">Miqdor:</span>
            <div className="flex items-center border rounded-md">
              <button className="w-10 h-10 flex items-center justify-center border-r" onClick={decreaseQuantity}>
                <Minus className="h-4 w-4" />
              </button>
              <span className="w-12 text-center">{quantity}</span>
              <button className="w-10 h-10 flex items-center justify-center border-l" onClick={increaseQuantity}>
                <Plus className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="mb-6">
            <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={addToCart}>
              <ShoppingCart className="mr-2 h-5 w-5" />
              Savatga qo'shish
            </Button>
          </div>

          <div className="border-t pt-6">
            <Tabs defaultValue="description">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="description">Tavsif</TabsTrigger>
                <TabsTrigger value="delivery">Yetkazib berish</TabsTrigger>
              </TabsList>
              <TabsContent value="description" className="pt-4">
                <p className="text-gray-700">{product.description}</p>
              </TabsContent>
              <TabsContent value="delivery" className="pt-4">
                <p className="text-gray-700">Yetkazib berish narxlari:</p>
                <ul className="list-disc pl-5 mt-2 space-y-1 text-gray-700">
                  <li>Shahar ichida - 10 000 so'm</li>
                  <li>Yaqin qishloqlarga - 15 000 so'm</li>
                  <li>Uzoq qishloqlarga - 20 000 so'm</li>
                </ul>
                <p className="mt-3 text-gray-700">Yetkazib berish vaqti: 30 daqiqadan 2 soatgacha.</p>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
