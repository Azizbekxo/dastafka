"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ShoppingBag, User, MapPin, LogOut, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"

// Mock data for orders
const mockOrders = [
  {
    id: "ORD-1001",
    date: "2025-05-11",
    status: "delivered",
    total: "45000",
    items: [
      { name: "Non mahsulotlari", quantity: 2, price: "5000" },
      { name: "Sut mahsulotlari", quantity: 1, price: "15000" },
    ],
  },
  {
    id: "ORD-1002",
    date: "2025-05-10",
    status: "processing",
    total: "25000",
    items: [{ name: "Go'sht mahsulotlari", quantity: 1, price: "45000" }],
  },
]

export default function ProfilePage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn")
    if (isLoggedIn !== "true") {
      router.push("/login")
      return
    }

    // Get user data
    const userJson = localStorage.getItem("user")
    if (userJson) {
      setUser(JSON.parse(userJson))
    }

    setIsLoading(false)
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn")
    router.push("/login")
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "new":
        return <Badge className="bg-blue-500">Yangi</Badge>
      case "processing":
        return <Badge className="bg-yellow-500">Jarayonda</Badge>
      case "delivering":
        return <Badge className="bg-purple-500">Yetkazilmoqda</Badge>
      case "delivered":
        return <Badge className="bg-green-500">Yetkazildi</Badge>
      case "cancelled":
        return <Badge className="bg-red-500">Bekor qilingan</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-6">Mening profilim</h1>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="profile">Profil</TabsTrigger>
          <TabsTrigger value="orders">Buyurtmalarim</TabsTrigger>
          <TabsTrigger value="addresses">Manzillarim</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Shaxsiy ma'lumotlar</CardTitle>
              <CardDescription>Profil ma'lumotlaringizni ko'ring va tahrirlang</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
                  <User className="h-8 w-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">{user?.fullName}</h3>
                  <p className="text-gray-500">{user?.phone}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <div>
                  <h4 className="font-medium text-gray-500 mb-2">To'liq ism</h4>
                  <p>{user?.fullName}</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-500 mb-2">Telefon raqam</h4>
                  <p>{user?.phone}</p>
                </div>
              </div>

              <div className="flex space-x-4 mt-6">
                <Button className="bg-blue-600 hover:bg-blue-700">Ma'lumotlarni tahrirlash</Button>
                <Button variant="outline" onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Chiqish
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Mening buyurtmalarim</CardTitle>
              <CardDescription>Barcha buyurtmalaringiz tarixi</CardDescription>
            </CardHeader>
            <CardContent>
              {mockOrders.length === 0 ? (
                <div className="text-center py-8">
                  <ShoppingBag className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Buyurtmalar yo'q</h3>
                  <p className="text-gray-500 mb-4">Siz hali buyurtma bermadingiz</p>
                  <Button asChild className="bg-blue-600 hover:bg-blue-700">
                    <Link href="/">Xarid qilishni boshlash</Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {mockOrders.map((order) => (
                    <div key={order.id} className="border rounded-lg p-4">
                      <div className="flex flex-wrap justify-between items-center mb-4">
                        <div>
                          <h3 className="font-bold">{order.id}</h3>
                          <p className="text-sm text-gray-500">
                            <Clock className="inline h-3 w-3 mr-1" />
                            {new Date(order.date).toLocaleDateString("uz-UZ")}
                          </p>
                        </div>
                        <div className="flex items-center space-x-4">
                          {getStatusBadge(order.status)}
                          <span className="font-bold text-blue-600">{order.total} so'm</span>
                        </div>
                      </div>
                      <div className="border-t pt-3">
                        <h4 className="font-medium mb-2">Buyurtma tarkibi:</h4>
                        <ul className="space-y-1">
                          {order.items.map((item, index) => (
                            <li key={index} className="text-sm">
                              {item.name} x {item.quantity} - {Number.parseInt(item.price) * item.quantity} so'm
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="mt-4">
                        <Button variant="outline" size="sm">
                          Batafsil ko'rish
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="addresses" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Mening manzillarim</CardTitle>
              <CardDescription>Yetkazib berish manzillaringizni boshqaring</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <MapPin className="h-5 w-5 text-blue-600 mt-0.5" />
                      <div>
                        <h3 className="font-medium">Asosiy manzil</h3>
                        <p className="text-gray-600">Boysun shahri, Mustaqillik ko'chasi, 45-uy</p>
                        <p className="text-sm text-gray-500">+998 90 123 45 67</p>
                      </div>
                    </div>
                    <div>
                      <Button variant="outline" size="sm">
                        Tahrirlash
                      </Button>
                    </div>
                  </div>
                </div>

                <Button className="bg-blue-600 hover:bg-blue-700">
                  <MapPin className="mr-2 h-4 w-4" />
                  Yangi manzil qo'shish
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
