import Link from "next/link"
import { ArrowRight, Clock, MapPin, ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { CategorySection } from "@/components/category-section"
import { PromoSection } from "@/components/promo-section"
import { ProductGrid } from "@/components/product-grid"
import { HeroSection } from "@/components/hero-section"
import { RegistrationCTA } from "@/components/registration-cta"

export default function Home() {
  return (
    <main className="min-h-screen">
      <HeroSection />

      {/* Ro'yxatdan o'tish CTA */}
      <RegistrationCTA />

      {/* Kategoriyalar */}
      <section className="py-10">
        <div className="container px-4 md:px-6">
          <h2 className="text-2xl font-bold mb-6">Kategoriyalar</h2>
          <CategorySection />
        </div>
      </section>

      {/* Aksiyalar */}
      <section className="py-6 bg-blue-50">
        <div className="container px-4 md:px-6">
          <PromoSection />
        </div>
      </section>

      {/* Mashhur mahsulotlar */}
      <section className="py-10">
        <div className="container px-4 md:px-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Mashhur mahsulotlar</h2>
            <Link href="/products" className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center">
              Barchasini ko'rish
              <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          <ProductGrid />
        </div>
      </section>

      {/* Yetkazib berish */}
      <section id="narxlar" className="py-10 bg-blue-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-4">Yetkazib berish narxlari</h2>
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Shahar ichida</h3>
                    <p className="text-gray-500 text-sm">Boysun shahri ichida</p>
                  </div>
                  <span className="font-bold text-blue-600">10 000 so'm</span>
                </div>
                <div className="bg-white p-4 rounded-lg flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Yaqin qishloqlarga</h3>
                    <p className="text-gray-500 text-sm">Boysun atrofidagi qishloqlar</p>
                  </div>
                  <span className="font-bold text-blue-600">15 000 so'm</span>
                </div>
                <div className="bg-white p-4 rounded-lg flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Uzoq qishloqlarga</h3>
                    <p className="text-gray-500 text-sm">Uzoq masofadagi qishloqlar</p>
                  </div>
                  <span className="font-bold text-blue-600">20 000 so'm</span>
                </div>
              </div>
              <div className="mt-6">
                <Button asChild className="bg-blue-600 hover:bg-blue-700">
                  <Link href="/cart">
                    Buyurtma berish
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
            <div className="md:w-1/2">
              <div className="bg-blue-100 p-6 rounded-full w-[300px] h-[300px] flex items-center justify-center mx-auto">
                <img alt="Yetkazib berish" className="max-w-[250px]" src="/placeholder.svg?height=250&width=250" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Aloqa */}
      <section id="aloqa" className="py-10 bg-blue-50">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex flex-col items-center p-6 bg-white rounded-lg shadow-sm">
              <div className="bg-blue-100 p-3 rounded-full mb-4">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Ish vaqti</h3>
              <p className="text-gray-500 text-center">24/7 - haftaning har kuni</p>
            </div>
            <div className="flex flex-col items-center p-6 bg-white rounded-lg shadow-sm">
              <div className="bg-blue-100 p-3 rounded-full mb-4">
                <MapPin className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Xizmat hududi</h3>
              <p className="text-gray-500 text-center">Boysun shahri va atrof qishloqlar</p>
            </div>
            <div className="flex flex-col items-center p-6 bg-white rounded-lg shadow-sm">
              <div className="bg-blue-100 p-3 rounded-full mb-4">
                <ShoppingBag className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Telefon</h3>
              <p className="text-gray-500 text-center">+998 20 000 58 24</p>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
