"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Eye, MapPin } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"

// Mock data for orders
const initialOrders = [
  {
    id: 1001,
    customer: "Alisher Karimov",
    phone: "+998 90 123 45 67",
    address: "Boysun shahri, Mustaqillik ko'chasi, 45-uy",
    location: { lat: 41.32, lng: 69.24, address: "Boysun shahri, Mustaqillik ko'chasi, 45-uy" },
    items: [
      { name: "Non mahsulotlari", quantity: 2, price: "5000" },
      { name: "Sut mahsulotlari", quantity: 1, price: "15000" },
    ],
    total: "25000",
    status: "new",
    courier: null,
    date: "2025-05-11T10:30:00",
  },
  {
    id: 1002,
    customer: "Gulnora Azizova",
    phone: "+998 90 987 65 43",
    address: "Boysun shahri, Navoiy ko'chasi, 12-uy",
    location: { lat: 41.31, lng: 69.22, address: "Boysun shahri, Navoiy ko'chasi, 12-uy" },
    items: [{ name: "Go'sht mahsulotlari", quantity: 1, price: "45000" }],
    total: "45000",
    status: "processing",
    courier: "Aziz Xolov",
    date: "2025-05-11T09:15:00",
  },
  {
    id: 1003,
    customer: "Bobur Rahimov",
    phone: "+998 90 456 78 90",
    address: "Boysun tumani, Qo'rg'oncha qishlog'i",
    location: { lat: 41.29, lng: 69.25, address: "Boysun tumani, Qo'rg'oncha qishlog'i" },
    items: [
      { name: "Non mahsulotlari", quantity: 3, price: "5000" },
      { name: "Sut mahsulotlari", quantity: 2, price: "15000" },
      { name: "Go'sht mahsulotlari", quantity: 1, price: "45000" },
    ],
    total: "85000",
    status: "delivered",
    courier: "Aziz Xolov",
    date: "2025-05-10T16:45:00",
  },
]

// Mock data for couriers
const couriers = [
  { id: 1, name: "Aziz Xolov" },
  { id: 2, name: "Bobur Karimov" },
  { id: 3, name: "Gulnora Azizova" },
]

export default function AdminOrders() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [orders, setOrders] = useState(initialOrders)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isLocationDialogOpen, setIsLocationDialogOpen] = useState(false)
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false)
  const [currentOrder, setCurrentOrder] = useState<any>(null)
  const [selectedCourier, setSelectedCourier] = useState<string>("")

  useEffect(() => {
    // Check if user is authenticated
    const checkAuth = () => {
      const isAuth = localStorage.getItem("admin-auth")
      if (isAuth === "true") {
        setIsAuthenticated(true)
      } else {
        router.push("/admin/login")
      }
      setIsLoading(false)
    }

    checkAuth()
  }, [router])

  const handleStatusChange = (orderId: number, newStatus: string) => {
    const updatedOrders = orders.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order))
    setOrders(updatedOrders)

    if (currentOrder && currentOrder.id === orderId) {
      setCurrentOrder({ ...currentOrder, status: newStatus })
    }
  }

  const handleAssignCourier = () => {
    if (!currentOrder || !selectedCourier) return

    const updatedOrders = orders.map((order) =>
      order.id === currentOrder.id ? { ...order, courier: selectedCourier, status: "processing" } : order,
    )
    setOrders(updatedOrders)
    setCurrentOrder({ ...currentOrder, courier: selectedCourier, status: "processing" })
    setIsAssignDialogOpen(false)
    setSelectedCourier("")
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "new":
        return <Badge className="bg-blue-500">Yangi</Badge>
      case "processing":
        return <Badge className="bg-yellow-500">Jarayonda</Badge>
      case "delivering":
        return <Badge className="bg-purple-500">Yetkazilmoqda</Badge>
      case "delivered":
        return <Badge className="bg-green-500">Yetkazildi</Badge>
      case "cancelled":
        return <Badge className="bg-red-500">Bekor qilingan</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("uz-UZ", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <AdminLayout>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Buyurtmalar</h2>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Mijoz</TableHead>
                <TableHead>Telefon</TableHead>
                <TableHead>Summa</TableHead>
                <TableHead>Sana</TableHead>
                <TableHead>Holati</TableHead>
                <TableHead>Kuryer</TableHead>
                <TableHead>Amallar</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell>{order.id}</TableCell>
                  <TableCell>{order.customer}</TableCell>
                  <TableCell>{order.phone}</TableCell>
                  <TableCell>{order.total} so'm</TableCell>
                  <TableCell>{formatDate(order.date)}</TableCell>
                  <TableCell>{getStatusBadge(order.status)}</TableCell>
                  <TableCell>
                    {order.courier ? (
                      order.courier
                    ) : (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setCurrentOrder(order)
                          setIsAssignDialogOpen(true)
                        }}
                      >
                        Kuryer tayinlash
                      </Button>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setCurrentOrder(order)
                          setIsViewDialogOpen(true)
                        }}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* View Order Dialog */}
        {currentOrder && (
          <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>Buyurtma #{currentOrder.id}</DialogTitle>
                <DialogDescription>Buyurtma ma'lumotlari</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-medium mb-2">Mijoz ma'lumotlari</h3>
                    <p>
                      <strong>Ism:</strong> {currentOrder.customer}
                    </p>
                    <p>
                      <strong>Telefon:</strong> {currentOrder.phone}
                    </p>
                    <p>
                      <strong>Manzil:</strong> {currentOrder.address}
                    </p>
                    {currentOrder.location && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-2"
                        onClick={() => setIsLocationDialogOpen(true)}
                      >
                        <MapPin className="h-4 w-4 mr-1" />
                        Xaritada ko'rish
                      </Button>
                    )}
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Buyurtma ma'lumotlari</h3>
                    <p>
                      <strong>ID:</strong> {currentOrder.id}
                    </p>
                    <p>
                      <strong>Sana:</strong> {formatDate(currentOrder.date)}
                    </p>
                    <p>
                      <strong>Holati:</strong>{" "}
                      <Select
                        value={currentOrder.status}
                        onValueChange={(value) => handleStatusChange(currentOrder.id, value)}
                      >
                        <SelectTrigger className="w-[180px] h-8 mt-1">
                          <SelectValue placeholder="Holatni tanlang" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new">Yangi</SelectItem>
                          <SelectItem value="processing">Jarayonda</SelectItem>
                          <SelectItem value="delivering">Yetkazilmoqda</SelectItem>
                          <SelectItem value="delivered">Yetkazildi</SelectItem>
                          <SelectItem value="cancelled">Bekor qilingan</SelectItem>
                        </SelectContent>
                      </Select>
                    </p>
                    <p className="mt-2">
                      <strong>Kuryer:</strong>{" "}
                      {currentOrder.courier ? (
                        currentOrder.courier
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-1"
                          onClick={() => setIsAssignDialogOpen(true)}
                        >
                          Kuryer tayinlash
                        </Button>
                      )}
                    </p>
                  </div>
                </div>

                <div className="mt-4">
                  <h3 className="font-medium mb-2">Buyurtma mahsulotlari</h3>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Mahsulot</TableHead>
                          <TableHead>Miqdori</TableHead>
                          <TableHead>Narxi</TableHead>
                          <TableHead>Jami</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {currentOrder.items.map((item: any, index: number) => (
                          <TableRow key={index}>
                            <TableCell>{item.name}</TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>{item.price} so'm</TableCell>
                            <TableCell>{Number.parseInt(item.price) * item.quantity} so'm</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>

                <div className="flex justify-end mt-4">
                  <div className="bg-gray-100 p-4 rounded-md">
                    <p className="text-lg font-bold">Jami: {currentOrder.total} so'm</p>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                  Yopish
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {/* Location Dialog */}
        {currentOrder && currentOrder.location && (
          <Dialog open={isLocationDialogOpen} onOpenChange={setIsLocationDialogOpen}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Mijoz joylashuvi</DialogTitle>
                <DialogDescription>Buyurtma #{currentOrder.id} uchun yetkazib berish manzili</DialogDescription>
              </DialogHeader>
              <div className="py-4">
                <div className="bg-gray-100 w-full h-[300px] rounded-md overflow-hidden relative">
                  {/* In a real app, you would use a map component here */}
                  <img
                    src={`/placeholder.svg?height=300&width=600&text=Map+at+${currentOrder.location.lat.toFixed(4)},${currentOrder.location.lng.toFixed(4)}`}
                    alt="Joylashuv xaritasi"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-2 right-2 bg-white p-2 rounded-md text-xs">
                    {currentOrder.location.lat.toFixed(6)}, {currentOrder.location.lng.toFixed(6)}
                  </div>
                </div>
                <div className="mt-4">
                  <p className="font-medium">Manzil:</p>
                  <p className="text-gray-600">{currentOrder.address}</p>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsLocationDialogOpen(false)}>
                  Yopish
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {/* Assign Courier Dialog */}
        {currentOrder && (
          <Dialog open={isAssignDialogOpen} onOpenChange={setIsAssignDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Kuryer tayinlash</DialogTitle>
                <DialogDescription>Buyurtma #{currentOrder.id} uchun kuryer tanlang</DialogDescription>
              </DialogHeader>
              <div className="py-4">
                <Label htmlFor="courier" className="mb-2 block">
                  Kuryer
                </Label>
                <Select value={selectedCourier} onValueChange={setSelectedCourier}>
                  <SelectTrigger>
                    <SelectValue placeholder="Kuryerni tanlang" />
                  </SelectTrigger>
                  <SelectContent>
                    {couriers.map((courier) => (
                      <SelectItem key={courier.id} value={courier.name}>
                        {courier.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAssignDialogOpen(false)}>
                  Bekor qilish
                </Button>
                <Button
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={handleAssignCourier}
                  disabled={!selectedCourier}
                >
                  Tayinlash
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </AdminLayout>
  )
}
