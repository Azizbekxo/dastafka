"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Edit, Plus, Trash2, Package } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock data for couriers
const initialCouriers = [
  {
    id: 1,
    name: "Aziz Xolov",
    phone: "+998 90 123 45 67",
    status: "active",
    activeOrders: 2,
    totalDeliveries: 156,
  },
  {
    id: 2,
    name: "Bobur Karimov",
    phone: "+998 90 987 65 43",
    status: "active",
    activeOrders: 1,
    totalDeliveries: 89,
  },
  {
    id: 3,
    name: "Gulnora Azizova",
    phone: "+998 90 456 78 90",
    status: "inactive",
    activeOrders: 0,
    totalDeliveries: 67,
  },
]

export default function AdminCouriers() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [couriers, setCouriers] = useState(initialCouriers)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [currentCourier, setCurrentCourier] = useState({
    id: 0,
    name: "",
    phone: "",
    status: "active",
    activeOrders: 0,
    totalDeliveries: 0,
  })

  useEffect(() => {
    // Check if user is authenticated
    const checkAuth = () => {
      const isAuth = localStorage.getItem("admin-auth")
      if (isAuth === "true") {
        setIsAuthenticated(true)
      } else {
        router.push("/admin/login")
      }
      setIsLoading(false)
    }

    checkAuth()
  }, [router])

  const handleAddCourier = () => {
    const newCourier = {
      ...currentCourier,
      id: couriers.length > 0 ? Math.max(...couriers.map((c) => c.id)) + 1 : 1,
      activeOrders: 0,
      totalDeliveries: 0,
    }
    setCouriers([...couriers, newCourier])
    setIsAddDialogOpen(false)
    resetCurrentCourier()
  }

  const handleEditCourier = () => {
    const updatedCouriers = couriers.map((courier) => (courier.id === currentCourier.id ? currentCourier : courier))
    setCouriers(updatedCouriers)
    setIsEditDialogOpen(false)
    resetCurrentCourier()
  }

  const handleDeleteCourier = () => {
    const filteredCouriers = couriers.filter((courier) => courier.id !== currentCourier.id)
    setCouriers(filteredCouriers)
    setIsDeleteDialogOpen(false)
    resetCurrentCourier()
  }

  const resetCurrentCourier = () => {
    setCurrentCourier({
      id: 0,
      name: "",
      phone: "",
      status: "active",
      activeOrders: 0,
      totalDeliveries: 0,
    })
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Faol</Badge>
      case "inactive":
        return <Badge className="bg-gray-500">Faol emas</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <AdminLayout>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Kuryerlar</h2>
          <Button
            className="bg-blue-600 hover:bg-blue-700"
            onClick={() => {
              resetCurrentCourier()
              setIsAddDialogOpen(true)
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            Yangi kuryer
          </Button>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Ism</TableHead>
                <TableHead>Telefon</TableHead>
                <TableHead>Holati</TableHead>
                <TableHead>Faol buyurtmalar</TableHead>
                <TableHead>Jami yetkazilgan</TableHead>
                <TableHead>Amallar</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {couriers.map((courier) => (
                <TableRow key={courier.id}>
                  <TableCell>{courier.id}</TableCell>
                  <TableCell>{courier.name}</TableCell>
                  <TableCell>{courier.phone}</TableCell>
                  <TableCell>{getStatusBadge(courier.status)}</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Package className="h-4 w-4 mr-1 text-blue-600" />
                      {courier.activeOrders}
                    </div>
                  </TableCell>
                  <TableCell>{courier.totalDeliveries}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setCurrentCourier(courier)
                          setIsEditDialogOpen(true)
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          setCurrentCourier(courier)
                          setIsDeleteDialogOpen(true)
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Add Courier Dialog */}
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Yangi kuryer qo'shish</DialogTitle>
              <DialogDescription>Yangi kuryer ma'lumotlarini kiriting</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Ism
                </Label>
                <Input
                  id="name"
                  value={currentCourier.name}
                  onChange={(e) => setCurrentCourier({ ...currentCourier, name: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="phone" className="text-right">
                  Telefon
                </Label>
                <Input
                  id="phone"
                  value={currentCourier.phone}
                  onChange={(e) => setCurrentCourier({ ...currentCourier, phone: e.target.value })}
                  className="col-span-3"
                  placeholder="+998 XX XXX XX XX"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="status" className="text-right">
                  Holati
                </Label>
                <Select
                  value={currentCourier.status}
                  onValueChange={(value) => setCurrentCourier({ ...currentCourier, status: value })}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Holatni tanlang" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Faol</SelectItem>
                    <SelectItem value="inactive">Faol emas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Bekor qilish
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleAddCourier}>
                Qo'shish
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Courier Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Kuryerni tahrirlash</DialogTitle>
              <DialogDescription>Kuryer ma'lumotlarini o'zgartiring</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-name" className="text-right">
                  Ism
                </Label>
                <Input
                  id="edit-name"
                  value={currentCourier.name}
                  onChange={(e) => setCurrentCourier({ ...currentCourier, name: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-phone" className="text-right">
                  Telefon
                </Label>
                <Input
                  id="edit-phone"
                  value={currentCourier.phone}
                  onChange={(e) => setCurrentCourier({ ...currentCourier, phone: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-status" className="text-right">
                  Holati
                </Label>
                <Select
                  value={currentCourier.status}
                  onValueChange={(value) => setCurrentCourier({ ...currentCourier, status: value })}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Holatni tanlang" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Faol</SelectItem>
                    <SelectItem value="inactive">Faol emas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Bekor qilish
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleEditCourier}>
                Saqlash
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Courier Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Kuryerni o'chirish</DialogTitle>
              <DialogDescription>Haqiqatan ham bu kuryerni o'chirmoqchimisiz?</DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <p>
                <strong>{currentCourier.name}</strong> kuryerini o'chirish. Bu amalni ortga qaytarib bo'lmaydi.
              </p>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                Bekor qilish
              </Button>
              <Button variant="destructive" onClick={handleDeleteCourier}>
                O'chirish
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  )
}
