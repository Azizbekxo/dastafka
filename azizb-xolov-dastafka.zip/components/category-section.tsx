import Link from "next/link"
import { Pill, ShoppingCart, UtensilsCrossed, Apple, Gift, Baby } from "lucide-react"

export function CategorySection() {
  const categories = [
    { name: "Oziq-ovqat", icon: <Apple className="h-6 w-6 text-blue-600" /> },
    { name: "Dori-darmon", icon: <Pill className="h-6 w-6 text-blue-600" /> },
    { name: "Chakana savdo", icon: <ShoppingCart className="h-6 w-6 text-blue-600" /> },
    { name: "Oshxona mahsulotlari", icon: <UtensilsCrossed className="h-6 w-6 text-blue-600" /> },
    { name: "Sovg'alar", icon: <Gift className="h-6 w-6 text-blue-600" /> },
    { name: "Bolalar uchun", icon: <Baby className="h-6 w-6 text-blue-600" /> },
  ]

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
      {categories.map((category, index) => (
        <Link
          key={index}
          href="#"
          className="flex flex-col items-center p-4 bg-white rounded-lg border border-gray-100 shadow-sm hover:shadow-md transition-all"
        >
          <div className="bg-blue-50 p-3 rounded-full mb-3">{category.icon}</div>
          <span className="text-sm font-medium text-center">{category.name}</span>
        </Link>
      ))}
    </div>
  )
}
