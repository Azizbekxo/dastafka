"use client"

import Link from "next/link"
import { ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

// Mock data for products
const products = [
  {
    id: 1,
    name: "Non mahsulotlari",
    price: "5 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 2,
    name: "Sut mahsulotlari",
    price: "15 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 3,
    name: "Go'sht mahsulotlari",
    price: "45 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 4,
    name: "Mevalar",
    price: "20 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 5,
    name: "Ichimliklar",
    price: "12 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 6,
    name: "Shirinliklar",
    price: "25 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
  },
]

export function ProductGrid() {
  const router = useRouter()

  const addToCart = (productId: number) => {
    // In a real app, you would add the product to the cart state or localStorage
    // For this demo, we'll just navigate to the cart page
    router.push("/cart")
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {products.map((product) => (
        <div
          key={product.id}
          className="bg-white rounded-lg border border-gray-100 shadow-sm overflow-hidden hover:shadow-md transition-all"
        >
          <Link href={`/products/${product.id}`} className="block p-2">
            <div className="aspect-square bg-gray-50 rounded-md overflow-hidden mb-2">
              <img
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <h3 className="font-medium text-sm mb-1">{product.name}</h3>
            <p className="text-blue-600 font-bold text-sm mb-2">{product.price}</p>
            <Button
              size="sm"
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={(e) => {
                e.preventDefault()
                addToCart(product.id)
              }}
            >
              <ShoppingCart className="h-4 w-4 mr-1" />
              Savatga
            </Button>
          </Link>
        </div>
      ))}
    </div>
  )
}
